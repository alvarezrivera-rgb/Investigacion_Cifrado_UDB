import random
import hashlib
from collections import Counter

MASK_64 = 0xFFFFFFFFFFFFFFFF

# =========================
# FUNCIONES BASE
# =========================

def fs(p, s):
    return (p ^ s) & MASK_64

def fg(p0, q):
    return (p0 + q) & MASK_64

def fm(s, q):
    return (s ^ (q << 1)) & MASK_64


# =========================
# GENERACIÓN DE LLAVES
# =========================

class KeyGenerator:
    def __init__(self, p, q, seed, n_keys):
        self.p = p
        self.q = q
        self.seed = seed
        self.n_keys = n_keys

    def generate_keys(self):
        keys = []
        s = self.seed

        for _ in range(self.n_keys):
            p0 = fs(self.p, s)
            k = fg(p0, self.q)
            keys.append(k)
            s = fm(s, self.q)

        return keys


# =========================
# FUNCIONES POLIMÓRFICAS
# =========================

def xor_func(data, key):
    return bytes([b ^ (key & 0xFF) for b in data])

def rotate_left(data, key):
    shift = key % 8
    return bytes([(b << shift | b >> (8 - shift)) & 0xFF for b in data])

def rotate_right(data, key):
    shift = key % 8
    return bytes([(b >> shift | b << (8 - shift)) & 0xFF for b in data])


FUNCTIONS = [xor_func, rotate_left, rotate_right]


# =========================
# CIFRADOR POLIMÓRFICO
# =========================

class PolymorphicCipher:

    def __init__(self, keys):
        self.keys = keys

    def get_psn(self, message):
        h = hashlib.sha256(message).hexdigest()
        return int(h[0], 16)

    def get_sequence(self, psn):
        return [FUNCTIONS[(psn + i) % len(FUNCTIONS)] for i in range(3)]

    def encrypt(self, msg, key_index):
        key = self.keys[key_index]
        data = msg.encode()

        psn = self.get_psn(data)
        seq = self.get_sequence(psn)

        for f in seq:
            data = f(data, key)

        return data, psn

    def decrypt(self, data, key_index, psn):
        key = self.keys[key_index]
        seq = self.get_sequence(psn)

        for f in reversed(seq):
            if f == rotate_left:
                data = rotate_right(data, key)
            elif f == rotate_right:
                data = rotate_left(data, key)
            else:
                data = f(data, key)

        return data.decode()


# =========================
# EVALUACIÓN DE LLAVES
# =========================

def evaluar_llaves(keys):
    print("\n=== EVALUACIÓN DE LLAVES ===")

    repetidas = len(keys) - len(set(keys))
    print("Llaves repetidas:", repetidas)

    diferencias = [abs(keys[i] - keys[i-1]) for i in range(1, len(keys))]
    print("Variación promedio:", sum(diferencias)/len(diferencias))

    bits_ones = sum(bin(k).count("1") for k in keys)
    total_bits = len(keys) * 64
    print("Proporción de bits en 1:", bits_ones / total_bits)


# =========================
# MAIN
# =========================

def main():

    print("=== SISTEMA CRIPTOGRÁFICO COMPLETO ===\n")

    p = random.getrandbits(64)
    q = random.getrandbits(64)
    seed = random.getrandbits(64)

    kg = KeyGenerator(p, q, seed, 20)
    keys = kg.generate_keys()

    print("Llaves generadas:")
    for i, k in enumerate(keys):
        print(f"K{i}: {k}")

    evaluar_llaves(keys)

    cipher = PolymorphicCipher(keys)

    mensajes = [
        ("FCM", "Inicio comunicacion"),
        ("RM", "Temperatura: 25C"),
        ("KUM", "Actualizar llaves"),
        ("LCM", "Fin comunicacion")
    ]

    print("\n=== PRUEBA DE MENSAJES ===")

    for i, (tipo, msg) in enumerate(mensajes):

        enc, psn = cipher.encrypt(msg, i)
        dec = cipher.decrypt(enc, i, psn)

        print(f"\nTipo: {tipo}")
        print("Original:", msg)
        print("Cifrado:", enc)
        print("PSN:", psn)
        print("Descifrado:", dec)


if __name__ == "__main__":
    main()