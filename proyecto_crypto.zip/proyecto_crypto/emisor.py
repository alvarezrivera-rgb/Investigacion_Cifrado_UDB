from crypto_system import *

p = 123456789
q = 987654321
seed = 111111

kg = KeyGenerator(p, q, seed, 10)
keys = kg.generate_keys()

cipher = PolymorphicCipher(keys)

mensaje = "Hola desde emisor"

enc, psn = cipher.encrypt(mensaje, 0)

print("MENSAJE CIFRADO:", enc)
print("PSN:", psn)

#El receptor debe pegar el valor de 'enc' y 'psn'que sale al ejecutar este script para descifrar el mensaje
#Luego, el receptor ejecuta este script para obtener el mensaje original