from crypto_system import *

p = 123456789
q = 987654321
seed = 111111

kg = KeyGenerator(p, q, seed, 10)
keys = kg.generate_keys()

cipher = PolymorphicCipher(keys)

# PEGA LOS VALORES DEL EMISOR
enc = b'\x8b\xac\xaf\xa2\xe3\xa7\xa6\xb0\xa7\xa6\xe3\xa6\xae\xaa\xb0\xac\xb1' # VALOR DE 'enc' DEL EMISOR
psn = 12 # VALOR DE 'psn' DEL EMISOR

mensaje = cipher.decrypt(enc, 0, psn)

print("MENSAJE RECIBIDO:", mensaje)

# El receptor debe pegar el valor de 'enc' y 'psn' que sale al ejecutar el script del emisor para descifrar el mensaje
# Luego, el receptor ejecuta este script para obtener el mensaje original